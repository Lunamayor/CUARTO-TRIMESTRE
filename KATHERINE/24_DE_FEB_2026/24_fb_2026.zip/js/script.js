const btn = document.getElementById("btnInfo");
const modal = document.getElementById("modal");
const cerrar = document.getElementById("cerrar");

btn.addEventListener("click", function() {

    modal.style.display = "flex";

});

cerrar.addEventListener("click", function() {

    modal.style.display = "none";

});


const btnMenu = document.getElementById("btnMenu");
const sidebar = document.getElementById("sidebar");

btnMenu.addEventListener("click", function() {

    sidebar.classList.toggle("active");

});




btnMenu.addEventListener("click", function() {

    sidebar.style.left = "0";

});

const cerrarSidebar = document.getElementById("cerrarSidebar");

cerrarSidebar.addEventListener("click", function() {

    sidebar.style.left = "-240px";

});